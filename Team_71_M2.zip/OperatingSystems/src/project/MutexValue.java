package project;

public enum MutexValue {
Zero,One;
}
