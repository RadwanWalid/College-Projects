package project;

public enum State {
	New, Ready, Running, Blocked, Finished;
}
