package controller;

import engine.City;
import engine.Game;
import engine.GameListener;
import engine.Player;

public class GameGUI implements GameListener {
	Player player;
	public GameGUI(String name , String city)
	{
		
	}
	
	public void onGameOver(Game game) {
		if(game.isGameOver())
			for(City c : game.getAvailableCities()) {
				if(!game.getPlayer().getControlledCities().contains(c))
					System.out.println("YOU LOST");
					return;
			}
		System.out.println("CONGRATULATIONS, YOU WON!");
	}

}
