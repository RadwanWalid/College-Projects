package exceptions;

@SuppressWarnings("serial")
public class MaxLevelException extends BuildingException {

	public MaxLevelException() {
		
	}

	public MaxLevelException(String s) {
		super(s);
		
	}

}
