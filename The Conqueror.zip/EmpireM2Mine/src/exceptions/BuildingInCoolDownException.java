package exceptions;

@SuppressWarnings("serial")
public class BuildingInCoolDownException extends BuildingException {

	public BuildingInCoolDownException() {
		
	}

	public BuildingInCoolDownException(String s) {
		super(s);
		
	}

}
