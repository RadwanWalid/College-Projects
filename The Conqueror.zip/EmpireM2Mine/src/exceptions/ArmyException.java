package exceptions;

@SuppressWarnings("serial")
public abstract class ArmyException extends EmpireException {

	public ArmyException() {
		
	}

	public ArmyException(String s) {
		super(s);
		
	}

}
