package exceptions;

public class UnitFullCapacityException extends ArmyException {
	public UnitFullCapacityException() {
		
	}
	
	public UnitFullCapacityException(String s) {
		super(s);
	}
}
