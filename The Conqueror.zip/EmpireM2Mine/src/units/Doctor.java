package units;

import exceptions.UnitFullCapacityException;

public class Doctor extends Unit{
	public Doctor(int level, int maxSoldierConunt, double idleUpkeep, double marchingUpkeep, double siegeUpkeep) {
		super(level, maxSoldierConunt, idleUpkeep, marchingUpkeep, siegeUpkeep);
	}
	
	public void heal(Unit healedUnit) throws UnitFullCapacityException {
		if(healedUnit.getCurrentSoldierCount()==0)
			return;
		if(healedUnit.getCurrentSoldierCount()==healedUnit.getMaxSoldierCount())
			throw new UnitFullCapacityException();
		double factor=0;
		if(this.getLevel()==1)
			factor = 0.2;
		else if(this.getLevel()==2)
			factor = 0.3;
		else
			factor = 0.4;
		healedUnit.setCurrentSoldierCount(healedUnit.getCurrentSoldierCount() + (int) (factor*healedUnit.getMaxSoldierCount()));
		if(healedUnit.getCurrentSoldierCount()>healedUnit.getMaxSoldierCount())
			healedUnit.setCurrentSoldierCount(healedUnit.getMaxSoldierCount());
	}
}
