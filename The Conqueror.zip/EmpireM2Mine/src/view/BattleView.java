package view;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import engine.City;
import engine.Game;
import exceptions.FriendlyFireException;
import exceptions.MaxCapacityException;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.*;

import units.Archer;
import units.Army;
import units.Cavalry;
import units.Infantry;
import units.Status;
import units.Unit;

public class BattleView extends JFrame{
	private JPanel attackArmy;
	private JPanel defArmy;
	private JButton autoResolve; 
	private JLabel deffendingArmy;
	private JLabel attackingArmy;
	private JPanel defArmy2;
	private JPanel attackArmy2;
	private JLabel attackingArmy2;
	private JLabel deffendingArmy2;
	//private Game game;
	public BattleView(Army att,Army def,Game game){
		setTitle("Battle Log");
		setBounds(50,50,800,600);
		setVisible(true);
		//setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(new GridLayout(0,1));
		
		attackArmy=new JPanel();
		defArmy = new JPanel();
		JPanel res=new JPanel();
		JLabel label1 = new JLabel(" Attacking army:");
		JLabel label2 = new JLabel(" Defending army:");

		attackArmy.setLayout(new GridLayout(0,att.getUnits().size()));
		defArmy.setLayout(new GridLayout(0,def.getUnits().size()));
		for(Unit u:att.getUnits()){
			attackArmy.add(new JLabel(u.getClass().getSimpleName()));
		}
		for(Unit u:att.getUnits()){
			attackArmy.add(new JLabel(u.getCurrentSoldierCount()+""));
		}
		for(Unit u:def.getUnits()){
			defArmy.add(new JLabel(u.getClass().getSimpleName()));
		}
		for(Unit u:def.getUnits()){
			defArmy.add(new JLabel(u.getCurrentSoldierCount()+""));
		}
		
		autoResolve=new JButton("Auto Resolve");
		autoResolve.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try {
					game.autoResolve(att, def);
					if(att.getUnits().size()>0){
						JOptionPane.showMessageDialog(null,"You have won ! And "+def.getCurrentLocation()+" is now yours to command");
					}
					else {
						JOptionPane.showMessageDialog(null,"you have lost");
						game.getPlayer().getControlledArmies().remove(att);
					}
					String s = att.getCurrentLocation();
					StartGameView.worldMapView.updateArmies();
					revalidate();
					repaint();
					if(game.isGameOver())
					{
						if(StartGameView.isWin(game))
							JOptionPane.showMessageDialog(null,"you Have Won!! Congratulations");
						else{
							JOptionPane.showMessageDialog(null,"Game Over!! You Have Lost :(");
							
						}
						System.exit(0);
					}
					
				} catch (FriendlyFireException e) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null,"You can't attack a friendly army");
				}
			}
			
		});
		JButton man=new JButton("Manual Resolve");
		man.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				ManualResolve a=new ManualResolve(att,def,game);
				
			}
			
		});
		this.add(label1);
		add(attackArmy);
		this.add(label2);

		add(defArmy);
		JPanel autopanel=new JPanel();
		JPanel manpanel=new JPanel();

		autopanel.add(autoResolve);
		manpanel.add(man);
		this.add(autopanel);
		this.add(manpanel);
		add(res);
		this.pack();
		this.revalidate();
		this.repaint();
		
	}	
	
	public static void main(String[]args) throws FriendlyFireException, IOException{
		Army a=new Army("Sparta");
		Army b=new Army("Rome");
		Archer t=new Archer(3,12,1,1,1);
		t.setParentArmy(a);
		Infantry u=new Infantry(3,12,1,1,1);
		u.setParentArmy(a);
		Archer v=new Archer(3,12,1,1,1);
		v.setParentArmy(a);
		Infantry w=new Infantry(3,12,1,1,1);
		w.setParentArmy(b);
		Infantry ww=new Infantry(3,12,1,1,1);
		ww.setParentArmy(b);
		Infantry xx=new Infantry(3,12,1,1,1);
		xx.setParentArmy(b);
		a.getUnits().add(t);
		a.getUnits().add(u);
		a.getUnits().add(v);
		b.getUnits().add(w);
		b.getUnits().add(ww);
		b.getUnits().add(xx);
		Game g=new Game("Boody","Sparta");
		
		BattleView zz = new BattleView(a,b,g);
		
	}

}
