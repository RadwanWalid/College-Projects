package view;

import java.awt.BorderLayout;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import engine.Game;
import units.Status;

public class StartGameView extends JFrame{
	
	private JPanel panel;
	private JTextArea enterName;
	private ArrayList<JButton> cities;
	private String selectedCity = "";
	static DataView dataView;
	static WorldMapView worldMapView;
	public ArrayList<JButton> getCities() {
		return cities;
	}

	public JPanel getPanel() {
		return panel;
	}
	public StartGameListener getListener() {
		return listener;
	}


	public JTextArea getEnterName() {
		return enterName;
	}

	private StartGameListener listener;
	public StartGameView() {
		this.setBounds(200,100,960,645);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		cities = new ArrayList<JButton>();
		panel = new JPanel(new GridLayout(12,0));
		
		JPanel nameData = new JPanel();
		JPanel chooseCityPanel = new JPanel();
		
		JLabel enterName = new JLabel("Enter your name: ",SwingConstants.CENTER);                                     
		//enterName.setPreferredSize(new Dimension(960,20));
		JTextField name = new JTextField();
		name.setSize(300,100);

		JLabel choose = new JLabel("Choose your city: ",SwingConstants.CENTER);

		JButton rome = new JButton("Rome");
		//rome.setIcon(new ImageIcon("images/Rome.jpeg"));
		JButton cairo = new JButton("Cairo");
		//cairo.setIcon(new ImageIcon("images/Cairo.jpeg"));
		JButton sparta = new JButton("Sparta");
		//sparta.setIcon(new ImageIcon("images/Sparta.jpeg"));
		JPanel startPanel = new JPanel();
		JButton start = new JButton("Start Game!");
		startPanel.add(start);
		listener = new StartGameListener(this);
		start.addActionListener(listener);
		
		nameData.add(enterName);
		//nameData.add(name);
		chooseCityPanel.add(choose);
	    panel.add(nameData);
	    panel.add(name);
	    chooseCityPanel.add(cairo);
	    chooseCityPanel.add(rome);
	    chooseCityPanel.add(sparta);
	    //panel.add(nameData);
	    panel.add(chooseCityPanel);
		panel.add(startPanel);
		
		cities.add(cairo);
		cities.add(rome);
		cities.add(sparta);
		rome.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				selectedCity = rome.getText();
			}
			
		});
		cairo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				selectedCity = cairo.getText();
			}
			
		});
		sparta.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				selectedCity = sparta.getText();
			}
			
		});
		start.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(name.getText().equals("")) {
					JOptionPane.showMessageDialog(null,"You haven't entered a name");
					return;
				}
					
				if(selectedCity.equals("")) {
					JOptionPane.showMessageDialog(null,"You haven't selected a city");
					return;
				}
					
				try {
					Game game = new Game(name.getText(),selectedCity);
					dataView = new DataView(game);
					
				worldMapView = new WorldMapView(game.getPlayer(),game);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				setVisible(false);
			}
			
		});
		
		

		//this.add(spaceL, BorderLayout.WEST);
		//this.add(spaceR, BorderLayout.EAST);
//		this.add(enterName, BorderLayout.NORTH);
		this.add(panel, BorderLayout.CENTER);
		
		this.revalidate();
		this.repaint();
	}
	public static boolean isWin(Game game) {
        // TODO Auto-generated method stub

        return game.getAvailableCities().size()==game.getPlayer().getControlledCities().size();
    }
	public static void main(String[] args) {
		//String s = Status.IDLE.name();
		//System.out.println(s);
		new StartGameView();
		
		
	}
}
