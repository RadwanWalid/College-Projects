package view;

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import engine.City;
import engine.Game;
import engine.Player;
import exceptions.FriendlyCityException;
import exceptions.TargetNotReachedException;
import units.Army;
import units.Status;
import units.Unit;

public class ArmyView extends JFrame {
	
	private JComboBox<String> targetCities;
	
	public ArmyView(Player player ,Army army, Game game){
		this.setTitle(army.getCurrentStatus().toString().toUpperCase() + " Army " + (int)(player.getControlledArmies().indexOf(army)+1));
		this.setBounds(350,150,500,500);
		this.setVisible(true);
		this.setLayout(new GridLayout(1,2));
		String loc = army.getCurrentLocation();
		boolean ally = false;
		for(City c : player.getControlledCities())
			if(c.getName().equals(loc))
				ally =true;
		JPanel action = new JPanel();
		action.setPreferredSize(new Dimension(250,400));
		GridLayout ac =  new GridLayout(3,1);
		//ac.setHgap(10);
		action.setBackground(new Color(255,255,255));
		//ac.setVgap(-100);
		action.setLayout(ac);
		
		targetCities = new JComboBox<String>();

		for(City c : game.getAvailableCities())
			if(!player.getControlledCities().contains(c))
				targetCities.addItem(c.getName());
		JPanel target = new JPanel();
		JButton targetCity = new JButton("Target City");
		targetCity.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				for(City c : game.getAvailableCities())
					if(c.getName().equals(targetCities.getSelectedItem()))
						game.targetCity(army, c.getName());
					army.setCurrentStatus(Status.MARCHING);
					StartGameView.worldMapView.updateArmies();
			}
		});
		target.add(targetCity);

		target.add(targetCities);

		if(army.getCurrentStatus()==Status.IDLE)
			action.add(target);
		
		
		JButton laySiege = new JButton("Lay Siege");
		laySiege.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				for(City c : game.getAvailableCities())
					if(c.getName().equals(army.getCurrentLocation()))
						try {
							player.laySiege(army, c);
						} catch (TargetNotReachedException e1) {
							// TODO Auto-generated catch block
							showMessageDialog(null,"you have not reached yet");						

						} catch (FriendlyCityException e1) {
							// TODO Auto-generated catch block
							showMessageDialog(null,"you can not attack your own city");						
							}
				StartGameView.worldMapView.updateArmies();
			}	
		});
		if(army.getCurrentStatus()==Status.IDLE &&  !ally)
			action.add(laySiege);
		
		
		JButton attack = new JButton("Attack");
		attack.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//Enter Attack here
				for(City c : game.getAvailableCities())
					if(c.getName().equals(army.getCurrentLocation()))
						new BattleView(army,c.getDefendingArmy(),game);
			}
		});
		
		if(army.getCurrentStatus()!=Status.MARCHING && !ally)
			action.add(attack);
		
		
		
		
		JTextArea armies = new JTextArea();
		armies.setPreferredSize(new Dimension(250,500));
		armies.setEditable(false);
		String s = "";
//		for(Army a : player.getControlledArmies()) {
//			if(army.getCurrentStatus().name().equals(army.getCurrentStatus().toString().toUpperCase())) {
				
					
					if(army.getCurrentStatus()==Status.BESIEGING) {
						for(Unit u : army.getUnits()) {
						s+= "  " + u.getClass().getSimpleName() + " \n     " +
								   "Level: " + u.getLevel() + " \n     " +
								   "Current Soldier Count: " +  u.getCurrentSoldierCount() + " \n     " +
								   "Max Soldier Count: " +  u.getMaxSoldierCount() + "\n     " +
						           "City Under Siege:  "+ army.getCurrentLocation() + "\n     ";
						}
					for(City c : game.getAvailableCities()) {
						if(c.getName().toLowerCase().equals(army.getCurrentLocation().toLowerCase()))
							s+=  "Turns Under Siege Till Now: " + c.getTurnsUnderSiege() + "\n" + "\n";
					    }
					}
					else if(army.getCurrentStatus()==Status.MARCHING) {
						for(Unit u : army.getUnits()) {
						s+="  " + u.getClass().getSimpleName() + " \n     " +
								   "Level: " + u.getLevel() + " \n     " +
								   "Current Soldier Count: " +  u.getCurrentSoldierCount() + " \n     " +
								   "Max Soldier Count: " +  u.getMaxSoldierCount() + "\n     " +
						           "Targeted City:  "+ army.getTarget() + "\n     ";
						}
					for(City c : game.getAvailableCities()) {
						if(c.getName().toLowerCase().equals(army.getTarget().toLowerCase()))
							s+=  "Turns Left to Reach Target: " + army.getDistancetoTarget() + "\n" + "\n";
					    }
					}
					else {
						for(Unit u : army.getUnits()) {
						s+="  " + u.getClass().getSimpleName() + " \n     " +
								   "Level: " + u.getLevel() + " \n     " +
								   "Current Soldier Count: " +  u.getCurrentSoldierCount() + " \n     " +
								   "Max Soldier Count: " +  u.getMaxSoldierCount() + "\n" + "\n" ;
						}
					}
					
//				}
				s+= "Current Location: " + army.getCurrentLocation();
//			}
//		}
		
		
		armies.setText(s);
		this.add(armies);
		this.add(action,BorderLayout.CENTER);
		this.pack();
		this.revalidate();
		this.repaint();
	}
}
