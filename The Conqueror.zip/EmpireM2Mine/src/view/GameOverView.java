package view;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import engine.City;
import engine.Game;

public class GameOverView extends JFrame{
	public GameOverView(Game game) {
		this.setTitle("Game Over!");
		this.setBounds(0,0,600,400);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(2,0));
		JLabel label = new JLabel();
		if(isWin(game))
			label.setText("You Won!");
		else 
			label.setText("Unfortunately You Lost!");
		JButton close = new JButton("Close");

		close.addActionListener(new ActionListener() {
	
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
			
		});
		panel.add(label);
		panel.add(close);
		this.add(panel);		
		this.validate();
		this.repaint();
		
		try {
		Thread.sleep(3000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.exit(0);
	}
	private boolean isWin(Game game) {
		// TODO Auto-generated method stub
		
		return game.getAvailableCities().size()==game.getPlayer().getControlledCities().size();
	}
	public static void main(String[] args) {
		try {
			new GameOverView(new Game("haytham" , "Rome"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
