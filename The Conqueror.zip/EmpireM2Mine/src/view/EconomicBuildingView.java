package view;
import javax.swing.*;

import buildings.EconomicBuilding;
import buildings.Farm;
import engine.City;
import engine.Player;
import exceptions.BuildingInCoolDownException;
import exceptions.MaxLevelException;
import exceptions.NotEnoughGoldException;

import static javax.swing.JOptionPane.showMessageDialog;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class EconomicBuildingView extends JFrame{
	private JPanel panel;
	private Player player;
	public EconomicBuildingView(EconomicBuilding eb , Player player) {
		this.player = player;
		// TODO Auto-generated constructor stub
		this.setTitle(eb.getClass().getSimpleName());
		JLabel type = new JLabel("Type: " + eb.getClass().getSimpleName(),SwingConstants.CENTER);
		JLabel level = new JLabel("level: " + eb.getLevel(),SwingConstants.CENTER);
		this.setBounds(200,100,600,400);
		this.setVisible(true);
		//this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new GridLayout(2,0));
		dataPanel.add(type);
		dataPanel.add(level);
		JPanel upgradePanel = new JPanel();
		JLabel upgradeCost = new JLabel("Upgrade Cost: " + eb.getUpgradeCost());
		JButton upgrade = new JButton("Upgrade");
		upgradePanel.add(upgradeCost);
		upgradePanel.add(upgrade);
		//upgradePanel.setLayout(new GridLayout(2,0));
		panel = new JPanel();
		panel.setLayout(new GridLayout(10,0));
		
		panel.add(dataPanel);
		panel.add(upgradePanel);
		
		this.add(panel, BorderLayout.CENTER);
		
		
		upgrade.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					player.upgradeBuilding(eb);
				} catch (NotEnoughGoldException e1) {
					// TODO Auto-generated catch block
					showMessageDialog(null, "not enough gold");
				} catch (BuildingInCoolDownException e1) {
					// TODO Auto-generated catch block
					showMessageDialog(null, "building is on cooldown");
				} catch (MaxLevelException e1) {
					// TODO Auto-generated catch block
					showMessageDialog(null, "building level is maximum");
				}
				
				level.setText("level: " + eb.getLevel());
				upgradeCost.setText(("Upgrade Cost: " + eb.getUpgradeCost()));
				StartGameView.dataView.updateData();
			}

	
		});
		
		
		
		this.revalidate();
		this.repaint();
	}
	public static void main(String[] args) {
		
		Farm farm = new Farm();
		farm.setLevel(1);
		farm.setUpgradeCost(1234);
		farm.setCoolDown(false);
		Player player = new Player("Haytham");
		player.setFood(10000);
		player.setTreasury(10000);
		new EconomicBuildingView(farm,player);
	}

}
