package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import controller.GameGUI;
public class StartGameListener implements ActionListener {
	private StartGameView dataGUI;
	public StartGameListener(StartGameView dataGUI) {
		// TODO Auto-generated constructor stub
		this.dataGUI = dataGUI;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		//new CityView();
		}

	}


