package view;

import javax.swing.*;

import engine.City;
import engine.Player;
import exceptions.MaxCapacityException;
import units.Archer;
import units.Army;
import units.Cavalry;
import units.Infantry;
import units.Unit;

import static javax.swing.JOptionPane.showMessageDialog;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class DefendingArmyView extends JFrame{

	private static final long serialVersionUID = 1L;
	private ArrayList<String> armyNames;
	private JButton showUnit;
	private JButton initiateArmy;
	private JComboBox<String> units;
	private JComboBox<String> armies;
	private JPanel panel;
	private Army defendingArmy;
	private Player player;
	
	public DefendingArmyView(Army army, Player player , City city) {
		// TODO Auto-generated constructor stub\
		defendingArmy = army;
		this.player = player;
		armyNames = new ArrayList<String>();
		this.setTitle("Defending Army");
		units = new JComboBox<String>();
		armies = new JComboBox<String>();
		updateArmies();
		for(Unit u : army.getUnits())
			units.addItem("Unit: " + (army.getUnits().indexOf(u)+1) + " Type : " + u.getClass().getSimpleName());
		
		this.setBounds(200,100,600,400);
		this.setVisible(true);
		//this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		showUnit = new JButton("Show Selected Unit");
		
		panel = new JPanel();
		panel.setLayout(new GridLayout(5,0));
		
		JPanel unitPanel = new JPanel();
		JLabel type = new JLabel("",SwingConstants.CENTER);
		
		JLabel level = new JLabel("",SwingConstants.CENTER);
		JLabel csoldiercount = new JLabel("",SwingConstants.CENTER);
		JLabel msoldiercount = new JLabel("",SwingConstants.CENTER);
		JPanel unitData = new JPanel();
		initiateArmy = new JButton("Initiate Army using selected unit");

		//unitData.setLayout(new BoxLayout(unitData, BoxLayout.Y_AXIS));
		unitPanel.add(units);
		unitPanel.add(showUnit);
		unitPanel.add(initiateArmy);

		panel.add(unitPanel);
		unitData.setLayout(new GridLayout(4,0,5,5));
		unitData.add(type);
		unitData.add(level);
		unitData.add(csoldiercount);
		unitData.add(msoldiercount);
		
		panel.add(unitData);
		
		
		showUnit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(units.getSelectedIndex()==-1) {
					showMessageDialog(null, "army is empty");
					return;
				}
				Unit u = army.getUnits().get(units.getSelectedIndex());

					
				type.setText("Type: " + u.getClass().getSimpleName());
				level.setText("Level: " + u.getLevel());
				csoldiercount.setText("Current no of soldiers: " + u.getCurrentSoldierCount());
				msoldiercount.setText("Max no of soldiers: " + u.getMaxSoldierCount());
			}
			
		}
		);
		initiateArmy.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				// TODO Auto-generated method stub
				if(units.getSelectedIndex()==-1) {
					showMessageDialog(null,"you havent selected a Unit");
					return;
				}
				player.initiateArmy(city, army.getUnits().get(units.getSelectedIndex()));
				updateDefendingArmy();
				updateArmies();
				if(StartGameView.worldMapView!=null)
					StartGameView.worldMapView.updateArmies();
			}


			
		});
		JButton relocateunit = new JButton("Relocate selected unit into selected army");
		relocateunit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			if(armies.getSelectedIndex()==-1) {
				showMessageDialog(null , "you have not selected an Army");
				return;
			}
			if(units.getSelectedIndex()==-1) {
				showMessageDialog(null , "you have not selected a unit");
				return;
			}
			String item = (String)armies.getSelectedItem();
				int index = Character.getNumericValue(item.charAt(item.length()-1))-1;
				try {
					player.getControlledArmies().get(index).relocateUnit(defendingArmy.getUnits().get(units.getSelectedIndex()));
				} catch (MaxCapacityException e1) {
					// TODO Auto-generated catch block
					showMessageDialog(null , "This Army Has Maximum Capacity");
				}
				updateDefendingArmy();
				updateArmies();
			}
			
		});
		//update
		JPanel relocatePanel = new JPanel();
		relocatePanel.add(armies);
		relocatePanel.add(relocateunit);
		panel.add(relocatePanel);
		this.add(panel,BorderLayout.CENTER);

		this.revalidate();
		this.repaint();
	}
	public void updateArmies() {
		// TODO Auto-generated method stub
		DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(toStringArrayArmy(player.getControlledArmies()));
		armies.setModel(model);
	}
	private String[] toStringArrayArmy(ArrayList<Army> controlledArmies) {
		armyNames.clear();
		for(Army a : controlledArmies)
			if(a.getCurrentLocation().equals(defendingArmy.getCurrentLocation()))
				armyNames.add("Army " + (controlledArmies.indexOf(a)+1));
		String [] res = new String[armyNames.size()];
		int i = 0;
		for(String s : armyNames)
			res[i++] = s;
		return res;
		// TODO Auto-generated method stub

	}
	public void updateDefendingArmy() {
		// TODO Auto-generated method stub
		DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(toStringArrayDef(defendingArmy.getUnits()));
		units.setModel(model);
	}
	private String[] toStringArrayDef(ArrayList<Unit> units2) {
		// TODO Auto-generated method stub
		String [] res = new String[units2.size()];
		int i = 0;
		for(Unit u : units2)
			res[i++] =  "Unit: " + (units2.indexOf(u)+1) + " Type : " + u.getClass().getSimpleName();
		return res;
	}
	public static void main(String[] args) {
		
		Army army = new Army("currentLocation");
		army.getUnits().add(new Archer(1,10,20,30,40));
		army.getUnits().add(new Cavalry(2,15,20,30,40));
		army.getUnits().add(new Infantry(3,30,20,30,40));
		army.getUnits().add(new Infantry(1,12,20,30,40));
		Player player = new Player("Haytham");
		new DefendingArmyView(army,player,new City("Rome"));
	}

}
