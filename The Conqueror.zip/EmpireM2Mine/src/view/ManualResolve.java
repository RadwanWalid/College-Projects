package view;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import engine.Game;
import exceptions.FriendlyFireException;
import units.Archer;
import units.Army;
import units.Cavalry;
import units.Infantry;
import units.Unit;
import static javax.swing.JOptionPane.showMessageDialog;

public class ManualResolve extends JFrame{
	private JComboBox<String> atck;
	private JComboBox<String> deffend;
	private JPanel table;
	public JPanel log;
	
	public ManualResolve(Army att,Army deff,Game game){
		this.setLayout(new GridLayout(2,0));
		table=new JPanel();
		log=new JPanel();
		table.setLayout(new GridLayout(5,0));
		setTitle("Manual Battle");
		setBounds(50,50,800,600);
		setVisible(true);
		//setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		atck = new JComboBox<String>();
		deffend=new JComboBox<String>();
		
		for(Unit u: att.getUnits()){
			atck.addItem("Unit " + (att.getUnits().indexOf(u)+1) + " "+u.getClass().getSimpleName()+ " " + u.getCurrentSoldierCount() + " units");
		}
		for(Unit u: deff.getUnits()){
			deffend.addItem("Unit " + (deff.getUnits().indexOf(u)+1)+" "+u.getClass().getSimpleName() + " " + u.getCurrentSoldierCount() + " units");
		}
		log.setLayout(new GridLayout(20,0));
		JButton attackbutton=new JButton("Attack");
		attackbutton.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				int attackindex=atck.getSelectedIndex();
				int defindex=deffend.getSelectedIndex();
				JLabel attacklog= new JLabel("Unit "+att.getUnits().get(attackindex).getClass().getSimpleName()+" attacked "+deff.getUnits().get(attackindex).getClass().getSimpleName());
				JLabel defflog 	=new JLabel("Unit "+deff.getUnits().get(attackindex).getClass().getSimpleName()+" attacked "+att.getUnits().get(attackindex).getClass().getSimpleName());
				try {
					att.getUnits().get(attackindex).attack(deff.getUnits().get(defindex));
					log.add(attacklog);

					if(deff.getUnits().size()==0){
						JOptionPane.showMessageDialog(null,"You Have Won and "+deff.getCurrentLocation()+" is now yours to command");
						setVisible(false);
						game.occupy(att, deff.getCurrentLocation());
						if(game.isGameOver())
						{
							if(StartGameView.isWin(game))
								JOptionPane.showMessageDialog(null,"You Have Won!! Congratulations");
							else{
								JOptionPane.showMessageDialog(null,"Game Over!! You Have Lost :(");
								
							}
							System.exit(0);
						}
						return;
				}

					
					deff.getUnits().get(defindex).attack(att.getUnits().get(attackindex));
					log.add(defflog);
					if(att.getUnits().size()==0){
						
						game.getPlayer().getControlledArmies().remove(att);
						
						JOptionPane.showMessageDialog(null,"You Have Lost :( ");
						setVisible(false);
						
					}
					StartGameView.worldMapView.updateArmies();
					
					
				} catch (FriendlyFireException e) {
					// TODO Auto-generated catch block
					showMessageDialog(null,"you can not attack your allies!");
				}
				
				
				updateboxes(att.getUnits(),deff.getUnits());
				revalidate();
				repaint();
				
			}


			
		});
		
		
		
		JLabel a=new JLabel("Attacking Army");
		JLabel b=new JLabel("Deffending Army");
		table.add(a);
		table.add(atck);
		table.add(b);
		table.add(deffend);
		table.add(attackbutton);
		this.add(table);
		this.add(log);
		this.revalidate();
		this.repaint();
	}
	public void updateboxes(ArrayList<Unit> a,ArrayList<Unit> d) {
		// TODO Auto-generated method stub
		DefaultComboBoxModel<String> attackmodel = new DefaultComboBoxModel<String>(toStringArr(a));
		DefaultComboBoxModel<String> defendmodel = new DefaultComboBoxModel<String>(toStringArr(d));
		atck.setModel(attackmodel);
		deffend.setModel(defendmodel);
	}
	private String[] toStringArr(ArrayList<Unit> d) {
		String[] res = new String[d.size()];
		int i = 0;
		for(Unit u : d)
			res[i++] = "Unit " + (d.indexOf(u)+1) + " "+u.getClass().getSimpleName() + " " + u.getCurrentSoldierCount() + " units";
		// TODO Auto-generated method stub
		return res;
	}
	public static void main(String[]args) throws IOException{
		Game game=new Game("Boda","Rome");
		Army a=new Army("Sparta");
		Army b=new Army("Rome");
//		Archer t=new Archer(3,12,1,1,1);
//		t.setParentArmy(a);
//		Infantry u=new Infantry(3,12,1,1,1);
//		u.setParentArmy(a);
		Archer v=new Archer(3,12,1,1,1);
		v.setParentArmy(a);
		Infantry w=new Infantry(3,12,1,1,1);
		w.setParentArmy(b);
		Infantry ww=new Infantry(3,12,1,1,1);
		ww.setParentArmy(b);
		Infantry xx=new Infantry(3,12,1,1,1);
		xx.setParentArmy(b);
//		a.getUnits().add(t);
//		a.getUnits().add(u);
		a.getUnits().add(v);
		b.getUnits().add(w);
		b.getUnits().add(ww);
		b.getUnits().add(xx);
//		try {
//			t.attack(ww);
//		} catch (FriendlyFireException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println(b.getUnits().get(1).getCurrentSoldierCount());
		ManualResolve m=new ManualResolve(a,b,game);
		
	}

}
