//package views;
//import javax.swing.JFrame;
//
//import engine.Game;
//import exceptions.FriendlyFireException;
//
//import java.awt.BorderLayout;
//import java.awt.Dimension;
//import java.awt.GridLayout;
//import java.io.IOException;
//import java.util.ArrayList;
//
//import javax.swing.JButton;
//import javax.swing.JLabel;
//import javax.swing.JPanel;
//import javax.swing.JTextArea;
//import javax.swing.JTextField;
//import javax.swing.SwingConstants;
//
//import units.Archer;
//import units.Army;
//import units.Infantry;
//public class BatleView2 {
//	private JPanel attackArmy;
//	private JPanel defArmy;
//	private JLabel deffendingArmy;
//	private JLabel attackingArmy;
//	private JPanel defArmy2;
//	private JPanel attackArmy2;
//	private JLabel attackingArmy2;
//	private JLabel deffendingArmy2;
//	//private Game game;
//	public BattleView(Army att,Army def){
//		setTitle("Battle Log");
//		setBounds(50,50,800,600);
//		setVisible(true);
//		setDefaultCloseOperation(EXIT_ON_CLOSE);
//		this.setLayout(new GridLayout(0,1));
//		
//		attackArmy=new JPanel();
//		defArmy = new JPanel();
//		attackArmy.setLayout(new GridLayout(0,3));
//		defArmy.setLayout(new GridLayout(0,3));
//		attackingArmy = new JLabel("Attacking Army",SwingConstants.CENTER);
//		deffendingArmy= new JLabel("Deffending Army",SwingConstants.CENTER);
//		attackingArmy2 = new JLabel("Attacking Army",SwingConstants.CENTER);
//		deffendingArmy2= new JLabel("Deffending Army",SwingConstants.CENTER);
//		add(attackingArmy);
//		attackArmy.add(new JTextArea("Infantry"));
//		attackArmy.add(new JTextArea("Archers"));
//		attackArmy.add(new JTextArea("Cavalry"));
//		attackArmy.add(new JTextArea("3"));
//		attackArmy.add(new JTextArea("5"));
//		attackArmy.add(new JTextArea("10"));
//		attackArmy.setVisible(true);
//		defArmy.add(new JTextArea("Infantry"));
//		defArmy.add(new JTextArea("Archers"));
//		defArmy.add(new JTextArea("Cavalry"));
//		defArmy.add(new JTextArea("3"));
//		defArmy.add(new JTextArea("5"));
//		defArmy.add(new JTextArea("10"));
//		add(attackArmy);
//		add(deffendingArmy);
//		add(defArmy);
//		JLabel x =new JLabel("You autoResolved",SwingConstants.CENTER);
//		add(x);
//		attackArmy2=new JPanel();
//		defArmy2 = new JPanel();
//		attackArmy2.setLayout(new GridLayout(0,3));
//		defArmy2.setLayout(new GridLayout(0,3));
//		defArmy2.add(new JTextArea("Infantry"));
//		defArmy2.add(new JTextArea("Archers"));
//		defArmy2.add(new JTextArea("Cavalry"));
//		defArmy2.add(new JTextArea("2"));
//		defArmy2.add(new JTextArea("0"));
//		defArmy2.add(new JTextArea("5"));
//		attackArmy2.add(new JTextArea("Infantry"));
//		attackArmy2.add(new JTextArea("Archers"));
//		attackArmy2.add(new JTextArea("Cavalry"));
//		attackArmy2.add(new JTextArea("0"));
//		attackArmy2.add(new JTextArea("0"));
//		attackArmy2.add(new JTextArea("0"));
//		add(attackingArmy2);
//		add(attackArmy2);
//		add(deffendingArmy2);
//		add(defArmy2);
//		JLabel res=new JLabel("You Lost Ya Big NOOB",SwingConstants.CENTER);
//		add(res);
//		this.revalidate();
//		this.repaint();
//		
//	}	
//	
//	public static void main(String[]args) throws FriendlyFireException, IOException{
//		BattleView b = new BattleView();
//		
//	}
//
//}
