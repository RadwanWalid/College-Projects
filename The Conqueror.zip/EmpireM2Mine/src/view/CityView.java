package view;
import static javax.swing.JOptionPane.showMessageDialog;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import buildings.ArcheryRange;
import buildings.Barracks;
import buildings.EconomicBuilding;
import buildings.Farm;
import buildings.Market;
import buildings.MilitaryBuilding;
import buildings.Stable;
import engine.City;
import engine.Player;
import exceptions.NotEnoughGoldException;
import units.Archer;
import units.Army;
import units.Cavalry;
import units.Infantry;
import buildings.Building;
public class CityView extends JFrame {
	private static final long serialVersionUID = 1L;
	
	//private ArrayList<JButton> cityButtons;
	private JPanel panel;
	private JButton defendingArmy;
	private JLabel turnsUnderSiege;
	private JLabel underSiege;
	private City city;
	private JComboBox<String> ecobuildingNames;
	private JComboBox<String> milbuildingNames;
	static DefendingArmyView defendingArmyView;
	public CityView(City city , Player player) {
		this.setTitle(city.getName());
		this.city = city;
		defendingArmy = new JButton("View Defending Army");
		
		turnsUnderSiege = new JLabel("turns under siege: " + city.getTurnsUnderSiege(),SwingConstants.CENTER);
		underSiege = new JLabel("city under siege: " + (city.isUnderSiege()? "yes": "no"),SwingConstants.CENTER);
		
		this.setBounds(200,100,960,645);
		this.setVisible(true);
		//this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		// TODO Auto-generated constructor stub
		ecobuildingNames = new JComboBox<String>();
		milbuildingNames = new JComboBox<String>();
		updateBuildingsView();
		panel = new JPanel();
		panel.setPreferredSize(new Dimension(300,625));
		panel.setLayout(new GridLayout(5,0));
		JPanel defendingArmypanel = new JPanel();
		defendingArmypanel.add(defendingArmy);
		//panel.add(defendingArmypanel);
		
		JPanel siegePanel = new JPanel();
		
		siegePanel.setLayout(new GridLayout(2,0));
		if(city.isUnderSiege())
			siegePanel.add(turnsUnderSiege);

		siegePanel.add(underSiege);
		JPanel buildingspanel = new JPanel();
		buildingspanel.setLayout(new GridLayout(4,0));
		buildingspanel.add(defendingArmypanel);
		buildingspanel.add(new CustomField("Economic Buildings", ecobuildingNames, new ItemListener() {

			@Override
			public void onSelect(String value) {
				for(EconomicBuilding b : city.getEconomicalBuildings())
					if(b.getClass().getSimpleName().equals(value))
						new EconomicBuildingView(b,player);

			}

		},"select")  );
		
		buildingspanel.add(new CustomField("Military Buildings", milbuildingNames, new ItemListener() {

			@Override
			public void onSelect(String value) {
				for(MilitaryBuilding b : city.getMilitaryBuildings())
					if(b.getClass().getSimpleName().equals(value))
						new MilitaryBuildingView(b,player,city.getName());
				

			}
			
		},"select"));
		String [] buildings = {"Farm" , "Market" , "Barracks" , "Stable" , "ArcheryRange"};
		JComboBox<String> buildingsbox = new JComboBox<String>(buildings);
		buildingspanel.add(new CustomField("New Building", buildingsbox, new ItemListener() {

			@Override
			public void onSelect(String value) {
				//showMessageDialog(null , value);
				try {
					//System.out.println(city.getEconomicalBuildings().toString());

					player.build(value, city.getName());
					updateBuildingsView();
					revalidate();
					repaint();
					//System.out.println(city.getEconomicalBuildings().toString());
					
				} catch (NotEnoughGoldException e) {
					// TODO Auto-generated catch block
					showMessageDialog(null , "you do not have enough gold");
				}

			}
			
		},"build"));
		
		panel.add(buildingspanel);
		
		JTextArea armies = new JTextArea("");
		armies.setEditable(false);
		
		JLabel armiesDataLabel = new JLabel("Armies currently in this City: ");
		String armiesData = "";
		int i = 1;
		for(Army army : player.getControlledArmies()) {
			if(army.getCurrentLocation().equals(city.getName()))
				armiesData+= (i++) + ": number of units : "+army.getUnits().size() + " status: " + army.getCurrentStatus();
		}
		armies.setText(armiesData);
		JPanel armiesPanel = new JPanel();
		panel.add(armiesDataLabel);
		panel.add(armies);
		
		defendingArmy.addActionListener(new ActionListener() {

			@Override
			
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				defendingArmyView =	new DefendingArmyView(city.getDefendingArmy(),player,city);
			}
			
		});
		
		
		//siegePanel.add(armiesPanel);
		
		
		panel.add(siegePanel);
		this.add(panel, BorderLayout.CENTER);
		this.revalidate();
		this.repaint();
		
	}
	public void updateBuildingsView() {
		DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>( toStringArrayE(city.getEconomicalBuildings()) );

		ecobuildingNames.setModel(model); //= new JComboBox<String>(toStringArrayE(city.getEconomicalBuildings()));
		 model = new DefaultComboBoxModel<>(toStringArrayM(city.getMilitaryBuildings()) );

		milbuildingNames.setModel(model);// = new JComboBox<String>(toStringArrayM(city.getMilitaryBuildings()));
			
		
	}
	public String[] toStringArrayE(ArrayList<EconomicBuilding> al){
		String res [] = new String [al.size()];
		int i = 0;
		for(Building b : al)
			res[i++] = b.getClass().getSimpleName();
		return res;
		
	}
	public String[] toStringArrayM(ArrayList<MilitaryBuilding> al){
		String res [] = new String [al.size()];
		int i = 0;
		for(Building b : al)
			res[i++] = b.getClass().getSimpleName();
		return res;
		
	}
	static interface ItemListener{
		void onSelect(String value);
	}
	
	static private final class CustomField extends JPanel {
		private static final long serialVersionUID = 1L;
		
		private JComboBox<String> valuesList;
		
		CustomField(String label, JComboBox<String> combobox, ItemListener listener, String button) {
		    JButton select;
			add(new JLabel(label));

			add(combobox);
			add(select = new JButton(button));
			select.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					listener.onSelect((String) combobox.getSelectedItem());
					StartGameView.dataView.updateData();
				}
				
			});
		}
		
	}
	
	public static void main (String [] args) {
		City city = new City ("Haytham");
		
		Player player = new Player("Haythoom");
		player.getControlledArmies().add(new Army("Haytham"));
		player.getControlledCities().add(city);
		player.setTreasury(10000);
		city.setTurnsUnderSiege(3);
		city.setUnderSiege(true);
		//city.getEconomicalBuildings().add(new Farm());
		//city.getEconomicalBuildings().add(new Market());
		//city.getMilitaryBuildings().add(new Barracks());
		//city.getMilitaryBuildings().add(new Stable());
		//city.getMilitaryBuildings().add(new ArcheryRange());
		Army army = new Army(city.getName());
		army.getUnits().add(new Archer(1,10,20,30,40));
		army.getUnits().add(new Cavalry(2,15,20,30,40));
		army.getUnits().add(new Infantry(3,30,20,30,40));
		army.getUnits().add(new Infantry(1,12,20,30,40));
		city.setDefendingArmy(army);
		new CityView(city,player);
		//System.out.println((new Barracks()).getClass().getSimpleName());
	}

}
