package view;

import java.awt.BorderLayout;



import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.*;

import engine.City;
import engine.Game;
import engine.Player;
import units.Archer;
import units.Army;
import units.Cavalry;
import units.Infantry;
import units.Status;
import static javax.swing.JOptionPane.showMessageDialog;
public class WorldMapView extends JFrame {
	private JPanel map;
	private Game game;
	private JComboBox<String> idle;
	private JComboBox<String> marching;
	private JComboBox<String> besieging;
	private Player player;
	public WorldMapView(Player player, Game game) {
		this.player = player;
		this.setTitle("World Map");
		this.setBounds(300,100,700,500);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setLayout(new BorderLayout());
		JLabel world = new JLabel(new ImageIcon("images/Final.png"));
		map = new JPanel();
		world.setLayout(new FlowLayout());
		GridLayout space =  new GridLayout(3,0);
		map.setLayout(space);
		JPanel cities = new JPanel();
		ArrayList<JButton> buttons = new ArrayList<JButton>();
		for(int j=0;j<game.getAvailableCities().size();j++) {
			JButton button = new JButton(game.getAvailableCities().get(j).getName());
			button.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					for(City c : game.getAvailableCities())
						if(c.getName().equals(button.getText())){
							if(player.getControlledCities().contains(c))
								new CityView(c,game.getPlayer());
							else {
								JOptionPane.showMessageDialog(null,"you can not view a city you do not control");
								return;
							}
						}
				}
				
			});
			cities.add(button);
		}
		
		
		
		JPanel armyStatus = new JPanel();
		armyStatus.setLayout(new GridLayout(3,3));
		
		JLabel idleLabel = new JLabel("Idle Armies");
		idle = new JComboBox<String>();
		JButton bI = new JButton("View");
		bI.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(idle.getSelectedIndex()==-1) {
					showMessageDialog(null,"you havent selected an army");
					return;
				}
				String selected =(String) idle.getSelectedItem();
				int index = Character.getNumericValue(selected.charAt(selected.length()-1))-1;
						new ArmyView(player,player.getControlledArmies().get(index),game);	
			}
			
		}); 
		
		JLabel marchingLabel = new JLabel("Marching Armies");
		marching = new JComboBox<String>();
		JButton bM = new JButton("View");
		bM.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(marching.getSelectedIndex()==-1) {
					showMessageDialog(null,"you havent selected an army");
					return;
				}
				String selected =(String) marching.getSelectedItem();
				int index = Character.getNumericValue(selected.charAt(selected.length()-1))-1;
				new ArmyView(player,player.getControlledArmies().get(index),game);
			}
			
		}); 
		
		JLabel besiegingLabel = new JLabel("Besieging Armies");
		besieging = new JComboBox<String>();
		JButton bB = new JButton("View");
		bB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(besieging.getSelectedIndex()==-1) {
					showMessageDialog(null,"you havent selected an army");
					return;
				}
				String selected =(String) besieging.getSelectedItem();
				int index = Character.getNumericValue(selected.charAt(selected.length()-1))-1;
					new ArmyView(player,player.getControlledArmies().get(index),game);
			}
			
		}); 
		
		
		
		ArrayList<JButton> army = new ArrayList<JButton>();
		
		for(int i = 0; i<player.getControlledArmies().size();i++) {
			if(player.getControlledArmies().get(i).getCurrentStatus()==Status.IDLE) {
				idle.addItem(player.getControlledArmies().get(i).getClass().getSimpleName() + " " + (int) (i+1));
			}else if(player.getControlledArmies().get(i).getCurrentStatus()==Status.BESIEGING) {
				besieging.addItem(player.getControlledArmies().get(i).getClass().getSimpleName()+ " " + (int) (i+1));
			}else{
				marching.addItem(player.getControlledArmies().get(i).getClass().getSimpleName()+ " " + (int) (i+1));
			}
		}
		
		
		armyStatus.add(idleLabel);
		armyStatus.add(Box.createVerticalStrut(1));
		armyStatus.add(marchingLabel);
		armyStatus.add(Box.createVerticalStrut(1));
		armyStatus.add(besiegingLabel);
		armyStatus.add(idle);
		armyStatus.add(Box.createVerticalStrut(1));
		armyStatus.add(marching);
		armyStatus.add(Box.createVerticalStrut(1));
		armyStatus.add(besieging);
		armyStatus.add(bI);
		armyStatus.add(Box.createVerticalStrut(1));
		armyStatus.add(bM);
		armyStatus.add(Box.createVerticalStrut(1));
		armyStatus.add(bB);
		
		map.add(cities);
		map.add(armyStatus);
		//map.add(world);
		this.add(map);
		//this.add(world);
		//this.pack();
		this.revalidate();
		this.repaint();
	}
	
	public JPanel getMap() {
		return map;
	}

	public void setMap(JPanel map) {
		this.map = map;
	}

	public static void main(String[] args) throws IOException {
		
		//City c = new City("Rome");
		//p.getControlledCities().add(null);
		Game g =  new Game("Haytham","Cairo");
		Player p = g.getPlayer();
		
		p.setFood(400);
		p.setTreasury(500.5);
		
		Army a1 = new Army("Cairo");
		a1.setCurrentStatus(Status.IDLE);
		Archer archerI = new Archer(2,50,2,54,4);
		Infantry infantryI = new Infantry(3,50,2,54,4);
		Cavalry cavalryI = new Cavalry(1,50,2,54,4);
		a1.getUnits().add(archerI);
		a1.getUnits().add(infantryI);
		a1.getUnits().add(cavalryI);
		
		Army a2 = new Army("Cairo");
		a2.setCurrentStatus(Status.BESIEGING);
		Archer archerB = new Archer(1,47,68.5,50,2);
		Infantry infantryB = new Infantry(3,50,2,74,15);
		Cavalry cavalryB = new Cavalry(1,50,2,54,4);
		a2.getUnits().add(archerB);
		a2.getUnits().add(infantryB);
		a2.getUnits().add(cavalryB);
		a2.setCurrentLocation("Rome");
		
		Army a3 = new Army("Cairo");
		a3.setCurrentStatus(Status.MARCHING);
		Archer archerM = new Archer(1,60,2,54,4);
		Infantry infantryM = new Infantry(1,640,2,54,4);
		Cavalry cavalryM = new Cavalry(1,50,2,54,4);
		a3.getUnits().add(archerM);
		a3.getUnits().add(infantryM);
		a3.getUnits().add(cavalryM);
		a3.setTarget("Rome");
		
		Army a4 = new Army("Cairo");
		a4.setCurrentStatus(Status.IDLE);
		Archer archer4 = new Archer(2,50,2,54,4);
//		Infantry infantryI = new Infantry(3,50,2,54,4);
//		Cavalry cavalryI = new Cavalry(1,50,2,54,4);
		a4.getUnits().add(archer4);
//		a1.getUnits().add(infantryI);
//		a1.getUnits().add(cavalryI);
		
		Army a5 = new Army("Cairo");
		a2.setCurrentStatus(Status.BESIEGING);
		Archer archer5 = new Archer(1,47,68.5,50,2);
//		Infantry infantryB = new Infantry(3,50,2,74,15);
//		Cavalry cavalryB = new Cavalry(1,50,2,54,4);
		a5.getUnits().add(archerB);
//		a2.getUnits().add(infantryB);
//		a2.getUnits().add(cavalryB);
//		a2.setCurrentLocation("rome");
		p.getControlledArmies().add(a1);
		p.getControlledArmies().add(a2);
		p.getControlledArmies().add(a3);
		p.getControlledArmies().add(a4);
		p.getControlledArmies().add(a5);
		
		//g.getAvailableCities().add(c);
		g.setCurrentTurnCount(21);
		new WorldMapView(p,g);
	}

	public void updateArmies() {
		// TODO Auto-generated method stub
		DefaultComboBoxModel<String>idlemodel = new DefaultComboBoxModel<String>();
		DefaultComboBoxModel<String> besiegemodel = new DefaultComboBoxModel<String>();
		DefaultComboBoxModel<String> marchmodel = new DefaultComboBoxModel<String>();
		int i = 0;
		for(Army a : player.getControlledArmies() ) {
			
			if(a.getCurrentStatus()==Status.IDLE)
				idlemodel.addElement(a.getClass().getSimpleName() + " " +(++i));
			else if(a.getCurrentStatus()==Status.BESIEGING) 
				besiegemodel.addElement(a.getClass().getSimpleName()+ " " +(++i));
			else
				marchmodel.addElement(a.getClass().getSimpleName()+ " " +(++i));
			
		}
		idle.setModel(idlemodel);
		besieging.setModel(besiegemodel);
		marching.setModel(marchmodel);
		
	}
}
