package view;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import engine.City;
import engine.Game;
import units.Army;
import units.Status;
import static javax.swing.JOptionPane.showMessageDialog;
public class DataView extends JFrame {
	private Game game;
	JLabel name = new JLabel();
	JLabel gold = new JLabel();
	JLabel food = new JLabel();
	JLabel turn = new JLabel();
	public DataView(Game game) {
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.game = game;
		this.setTitle("player data");
		this.setBounds(50,50,200,200);
		this.setVisible(true);
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(5,0));
		JPanel namepanel = new JPanel();
		JPanel goldpanel = new JPanel();
		JPanel foodpanel = new JPanel();
		JPanel turnpanel = new JPanel();
		JPanel endturnpanel = new JPanel();
		JButton endTurn = new JButton("End Turn");
		endTurn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				game.endTurn();
				updateData();
				if(game.isGameOver())
				{
					if(StartGameView.isWin(game))
						JOptionPane.showMessageDialog(null,"you Have Won!! Congratulations");
					else{
						JOptionPane.showMessageDialog(null,"Game Over!! You Have Lost :(");
						
					}
					System.exit(0);
				}
				StartGameView.worldMapView.updateArmies();
				for(City c : game.getAvailableCities()) {
					if(c.getTurnsUnderSiege()==3) {
						showMessageDialog(null,"you reached maximum no of turns for sieging and you must start the attack now");
						for(Army a : game.getPlayer().getControlledArmies())
							if(a.getCurrentLocation().equals(c.getName()) && a.getCurrentStatus()==Status.BESIEGING)
								new BattleView(a,c.getDefendingArmy(),game);
						c.setTurnsUnderSiege(-1);

					}
				}
			}
			
		});
		updateData();
		namepanel.add(name);
		goldpanel.add(gold);
		foodpanel.add(food);
		turnpanel.add(turn);
		endturnpanel.add(endTurn);
		panel.add(namepanel);
		panel.add(goldpanel);
		panel.add(foodpanel);
		panel.add(turnpanel);
		
		panel.add(endturnpanel);
		this.add(panel);
		this.validate();
		this.repaint();

	}
	public static void main(String[] args) {
		try {
			new DataView(new Game("Ahmad Haytham",""));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void updateData() {

		name.setText("Name: " + game.getPlayer().getName());
		gold.setText("Gold: " + game.getPlayer().getTreasury());
		food.setText("Food: " + game.getPlayer().getFood());
		turn.setText("Current turn number: " + game.getCurrentTurnCount());
		
		//this.validate();
		//this.repaint();
	}

}
