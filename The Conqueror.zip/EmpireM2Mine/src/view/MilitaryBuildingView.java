package view;

import static javax.swing.JOptionPane.showMessageDialog;

import java.awt.BorderLayout;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import buildings.Barracks;
import buildings.EconomicBuilding;
import buildings.Farm;
import buildings.MilitaryBuilding;
import buildings.Stable;
import engine.City;
import engine.Player;
import exceptions.BuildingInCoolDownException;
import exceptions.MaxLevelException;
import exceptions.MaxRecruitedException;
import exceptions.NotEnoughGoldException;

public class MilitaryBuildingView extends JFrame {
	private Player player;
	private JPanel panel;
	private String cityName;
	
	public MilitaryBuildingView(MilitaryBuilding mb , Player player,String cityName){
		this.player = player;
		this.cityName = cityName;
		// TODO Auto-generated constructor stub
		this.setTitle(mb.getClass().getSimpleName());
		JLabel type = new JLabel("Type: " + mb.getClass().getSimpleName(),SwingConstants.CENTER);
		JLabel level = new JLabel("level: " + mb.getLevel(),SwingConstants.CENTER);
		this.setBounds(200,100,600,400);
		this.setVisible(true);
		//this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new GridLayout(2,0));
		dataPanel.add(type);
		dataPanel.add(level);
		JPanel upgradePanel = new JPanel();
		JLabel upgradeCost = new JLabel("Upgrade Cost: " + mb.getUpgradeCost());
		JButton upgrade = new JButton("Upgrade");
		upgradePanel.add(upgradeCost);
		upgradePanel.add(upgrade);
		//upgradePanel.setLayout(new GridLayout(2,0));
		panel = new JPanel();
		panel.setLayout(new GridLayout(10,0));
		
		panel.add(dataPanel);
		panel.add(upgradePanel);
		
		
		JPanel recruitPanel = new JPanel();
		JLabel recruitCost = new JLabel("Recruitment Cost: " + mb.getRecruitmentCost());
		JButton recruit = new JButton("Recruit Unit");
		recruitPanel.add(recruitCost);
		recruitPanel.add(recruit);
		panel.add(recruitPanel);
		this.add(panel, BorderLayout.CENTER);
		
		recruit.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				String type = "";
				if(mb instanceof Barracks)
					type = "infantry";
				else if (mb instanceof Stable)
					type = "cavalry";
				else
					type = "archer";
				
				// TODO Auto-generated method stub
				try {
					player.recruitUnit(type, cityName);
				} catch (BuildingInCoolDownException e1) {
					showMessageDialog(null,"Building is on cooldown, please wait till next turn.");
					
				} catch (MaxRecruitedException e1) {
					showMessageDialog(null,"Max recruited units reached, please wait till next turn."); 
				} catch (NotEnoughGoldException e1) {
					// TODO Auto-generated catch block
					showMessageDialog(null,"you do not have enough gold, please wait till next turn.");
				}
				StartGameView.dataView.updateData();
				if(!(CityView.defendingArmyView == null))
					CityView.defendingArmyView.updateDefendingArmy();
				
			}
			
		});
		
		upgrade.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					player.upgradeBuilding(mb);
				} catch (NotEnoughGoldException e1) {
					// TODO Auto-generated catch block
					showMessageDialog(null, "not enough gold, please wait till next turn.");
				} catch (BuildingInCoolDownException e1) {
					// TODO Auto-generated catch block
					showMessageDialog(null, "building is on cooldown, please wait till next turn.");
				} catch (MaxLevelException e1) {
					// TODO Auto-generated catch block
					showMessageDialog(null, "building level is maximum, please wait till next turn.");
				}
				
				level.setText("level: " + mb.getLevel());
				upgradeCost.setText(("Upgrade Cost: " + mb.getUpgradeCost()));
				recruitCost.setText("Recruitment Cost: " + mb.getRecruitmentCost());
				StartGameView.dataView.updateData();

			}

	
		});
		
		
		
		this.revalidate();
		this.repaint();

		
	}
	public static void main(String[] args) {
		
		Barracks barracks = new Barracks();
		barracks.setLevel(2);
		barracks.setUpgradeCost(1234);
		barracks.setCoolDown(false);
		Player player = new Player("Haytham");
		player.setFood(10000);
		player.setTreasury(10000);
		player.getControlledCities().add(new City("Haythoom"));
		player.getControlledCities().get(0).getMilitaryBuildings().add(barracks);
		
		new MilitaryBuildingView(barracks,player,"Haythoom");
	}

}
